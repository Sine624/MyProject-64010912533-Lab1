<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<h1>ร้านขายสมุด Kanokwan</h1>
    <?php
include ("connectdb.php");
$sql = "SELECT * FROM `category`";
$rs = mysqli_query($conn, $sql);
while ($data = mysqli_fetch_array ($rs)){
echo $data ['c_id']. "<br>";
echo $data ['c_name']. "<hr>";

}

mysqli_close($conn); //ปิดการเชื่อมต่อฐานข้อมูล
?>

</body>
</html>